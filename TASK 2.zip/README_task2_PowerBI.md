# Task 2: Data Visualization and Storytelling (Power BI)

## Objective
Create visualizations that convey a compelling business story.

## Dataset
**Sample Superstore** (`Sample - Superstore.csv`, your uploaded file) — 9,994 orders, 2014–2017.
Fields used: Order Date, Category, Sub-Category, Region, State, Sales, Profit, Discount.

## Tool used
Power BI Desktop.

## What I did
1. Imported `superstore.csv` and verified data types (dates as Date, Sales/Profit/Discount as numbers).
2. Added DAX measures: `Total Sales`, `Total Profit`, `Profit Margin`.
3. Built a Year-over-Year Sales & Profit trend chart (dual-axis line + column).
4. Built profit-by-Category and profit-by-Sub-Category bar charts, with conditional
   formatting (red = loss, teal = profit) to flag underperformers.
5. Binned `Discount` into ranges (0%, 1–20%, 21–40%, 41–60%, 60%+) and charted average
   profit per bin to show where discounting stops being profitable.
6. Built Region and State performance charts to locate where losses concentrate.
7. Added a Summary page laying out the story as 4 beats, each paired with a recommended action.
8. Exported the finished dashboard as a PDF.

## The story, in 4 beats
1. **Growth**: Sales +51%, Profit +89% (2014→2017) — the business is healthy overall.
2. **The leak**: Furniture earns almost as much revenue as Technology but only ~1/8th the profit.
3. **Root cause**: Losses are concentrated in Tables & Bookcases, and profit turns negative once
   discounts exceed 20%.
4. **Where it hurts**: Texas, Ohio, and Pennsylvania are the top loss-making states.

## Design choices
- One clear takeaway per chart — no chart included without a stated "so what."
- Color used only to mean something (red = loss-making, teal = profitable), not decoration.
- Charts kept to one idea each — no 3D, no unnecessary gridlines or clutter.
- Closing summary page ties every insight to a recommended action.

## Files
- `Sample - Superstore.csv` — source dataset (as provided)
- `Superstore_Visual_Story_Report.pdf` — exported dashboard/report
